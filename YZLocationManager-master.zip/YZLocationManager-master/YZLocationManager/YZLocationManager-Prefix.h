//
//  YZLocationManager-Prefix.h
//  YZLocationManager
//
//  Created by swf on 2017/2/21.
//  Copyright © 2017年 CancerQ. All rights reserved.
//

#ifndef YZLocationManager_Prefix_h
#define YZLocationManager_Prefix_h

#import "YZLocationManagerMacro.h"

#endif /* YZLocationManager_Prefix_h */
